import configparser

config = configparser.ConfigParser()
config.read('hw2.conf')

#print(config.get('hidost', 'hidost_tr_pca'))

