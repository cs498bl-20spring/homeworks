import numpy as np
import pickle
import sys
import copy

from config import config
from sklearn import datasets
from sklearn.metrics import roc_curve, auc, f1_score, classification_report, confusion_matrix
from sklearn.svm import LinearSVC
from sklearn.model_selection import GridSearchCV
from numpy.linalg import norm
import matplotlib as mpl
mpl.use('TkAgg')  # or whatever other backend that you want
import matplotlib.pyplot as plt


### DO NOT CHANGE THE FOLLOWING CONFIGURATION###
######################################################################
hidost_tr_pca = config.get('hidost', 'hidost_tr_pca')
hidost_te_pca = config.get('hidost', 'hidost_te_pca')
hidost_model = config.get('hidost', 'hidost_model')
hidost_retrain_model = config.get('hidost', 'hidost_retr_model')

pdfrate_tr_pca = config.get('pdfrate', 'pdfrate_tr_pca')
pdfrate_te_pca = config.get('pdfrate', 'pdfrate_te_pca')
pdfrate_model = config.get('pdfrate', 'pdfrate_model')
pdfrate_retrain_model = config.get('pdfrate', 'pdfrate_retr_model')

random_seed = config.getint('experiment', 'random_seed')
np.random.seed(random_seed) # Set random seed
######################################################################

def adversarial_once(model, x_seed, cost_coef):

    """
    Get the adversarial example of a malicious seed subject to the cost coefficient
    :param model: The target classification model.
    :param x_seed: The malicious seed. One-dimensional array.
    :param cost_coef: Cost coefficient of modifying features. Float.
    :return x_adv: The Adversarial example. one-dimensional array.
    """

    # TODO: Get the adversarial example, x_adv, of x_seed.

    return x_adv

def adversarial_examples(model, X_seed, cost_coef):

    """
    Get the adversarial examples of a array of malicious seeds subject to the cost coefficient
    :param model: The target classification model.
    :param X_seed: The array of malicious seeds. Two-dimensional array.
    :param cost_coef: Cost coefficient of modifying features. Float.
    :return X_adv: Adversarial examples. Two-dimensional array.
    """

    # TODO: Get the adversarial examples, X_adv, of X_seed.

    return X_adv

def train(X_train, y_train):

    """
    Get PDF malware classifier ( use grid-search and cross-validation to select parameters).
    :param X_train: Feature vectors of training data. Two-dimensional array.
    :param y_tain: Labels of training data. One-dimensional array.
    :return model: Classification model.
    """

    tuned_param = {'C':[0.1, 1, 5, 10, 20]}

    # TODO: Built your classifiers with parameter tunning

    return model

def iterative_retraining(model, X_def_seed, X_train, y_train, cost_coef):

    """
    Iteratively retrain a classifier.
    :param model: Initial classification model. 
    :param X_def_seed: Array of mallicious seeds used to generate adversarial examples for retraining. Two-dimensional array.
    :param X_train: Feature vectors of training data. Two-dimensional array.
    :param y_tain: Labels of training data. One-dimensional array.
    :param cost_coef: Cost coefficient of modifying features. Float.
    """
    
    retrain_model = copy.deepcopy(model)

    # TODO: Iteratively retrain the classifier.

    return retrain_model
    
def evaluate_non_adv(model, X_test, y_test):

    """
    Evaluate PDF malware classifier on non-adversairial data.
    :param model: Classification model.
    :param X_test: Feature vectors of test data. Two-dimensional array.
    :param y_test: Labels of test data. One-dimensional array.    
    """

    # TODO: Implement the evaluation as you did in hw1.

def evaluate_attack(model, X_adv_seed, cost_coefs):

    """
    Evaluate the evasion attacks on a classifier with different attack strengths.
    Also can vbe used to evaluate robustness of a classifer.
    :param model: The target classifier
    :param X_adv_seed: The array of malicious seeds used by the adversary (attacker). Two-dimensional array.
    :param cost_coefs: The list of different cost coefficients for attacking. One-dimensional list of floats.
    """
    for attack_coef in cost_coefs:

        # TODO: Produce adversarial examples with different attack_coef and evalute them with the classifier
  

def evaluate_retraining(model, X_adv_seed, X_train, y_train, cost_coefs):

    """
    Evaluate the classifiers refined with iterative retraining under different retraining and actual attack strengths.
    :param model: The initial target classifier.
    :param X_adv_seed: The array of malicious seeds used by the actual attacker. Two-dimensional array.
    :param X_train: The feature vectors of the original training data. Two-dimensional array.
    :param X_test: The labels of the original training data. One-dimensional array.
    :param cost_coefs: The list of different cost coefficient. One-dimensional list of floats.
    """

    # Get the malicious seeds of the defender for iterative retraining
    def_seed_ind = np.random.choice(np.where(y_train==1)[0], 50)
    X_def_seed = X_train[def_seed_ind]

    # Iteraive retraining with different retraining strength
    for retraining_coef in cost_coefs:

        # TODO: Iteratively retrain your classifier using retraining_coef
        retrain_model = 
        
        # TODO: Evaluate your retrain_model with the evaluate_attack method 

        # TODO: Evaluate retrain_model on the non-adversarial data

if __name__ == "__main__":    
    if len(sys.argv) < 2:
        print("python main.py [classifier_name] [mode]")
        sys.exit(1)

    feat = sys.argv[1]
    mode = sys.argv[2]

    # Get the path to the target classifiers and dataset
    model_dir = hidost_model if feat == 'hidost' else pdfrate_model
    tr_pca_dir = hidost_tr_pca if feat == 'hidost' else pdfrate_tr_pca
    te_pca_dir = hidost_te_pca if feat == 'hidost' else pdfrate_te_pca

    # Load the classifiers and dataset
    model = pickle.load(open(model_dir, 'rb'))
    data_tr = datasets.load_svmlight_file(tr_pca_dir)
    X_train, y_train = data_tr[0], data_tr[1]
    X_train = X_train.toarray()    
    data_te = datasets.load_svmlight_file(te_pca_dir)
    X_test, y_test = data_te[0], data_te[1]
    X_test = X_test.toarray()

    # Get the malicious seeds of the attacker for evasion attacks
    adv_seed_ind = np.where(y_test==1)[0]
    X_adv_seed =  X_test[adv_seed_ind]

    cost_coefs = [0.1, 0.2, 0.3, 0.4, 0.5]
    if mode == 'attack':
        evaluate_attack(model, X_adv_seed, cost_coefs)
    elif mode == 'defense':
        evaluate_retraining(model, X_adv_seed, X_train, y_train, cost_coefs)
        